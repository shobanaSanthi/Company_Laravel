<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class employee_skill extends Model
{
    protected $table='employee_skill';
}
