<footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Company Employee Project 2022</span>
          </div>
        </div>
      </footer><?php /**PATH /home/shobana/projects/company/resources/views/includes/footer.blade.php ENDPATH**/ ?>