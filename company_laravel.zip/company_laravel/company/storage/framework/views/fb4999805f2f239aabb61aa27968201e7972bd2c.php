<?php $__env->startSection('content'); ?>
<style>
 .flex-container {
    display: flex;
}

.flex-child {
    flex: 1;
    border: 2px solid yellow;
    height:200px;
}  

.flex-child:first-child {
    margin-right: 20px;
} 
.green{
    background-color:green
}
.blue{
    background-color:blue
}
</style>

<div class="flex-container">

  <div class="flex-child green">
    <div style="color:white;font-size:30px">Total number of Employees: <?php echo e($count['user']); ?></div>
  </div>
  
  <div class="flex-child blue">
    <div style="color:white;font-size:30px">Total number of Skills:<?php echo e($count['skills']); ?></div>
  </div>
  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shobana/projects/company/resources/views/admin/empCount.blade.php ENDPATH**/ ?>