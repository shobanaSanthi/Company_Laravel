<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>error</title>
</head>
<style>
    div {
    width: 500px;
    height: 100px;  
    font-style:bold;
    position: absolute;
    top:0;
    font-size:27px;
    bottom: 0;
    left: 0;
    right: 0;
    
    margin: auto;
}
    </style>
<body style="background-color:black">
    <div class="text-center" style="color:white">
    401 | OOPs, This Page is Restricted for you</div>
</body>
</html><?php /**PATH /home/shobana/projects/company/resources/views/error_401.blade.php ENDPATH**/ ?>